<div class="contact-bk">
    <img src="<?php echo base_url('frontassets/image/contact1.jpg'); ?>" class="img-responsive">
    <div class="contact-text">
        <h1>contact us</h1>
        <div class="circle">

        </div>
    </div>
</div>
<div class="container">
    <div class="row">
        <div class="col-md-4">
            <div class="contact-add">
                <span>ADDRESS</span>
                <div class="half-circle"></div>
                <h4>DESIGN HOTEL CHENNAI</h4>
                <p>Phoenix Marketcity</p>
                <p>142, Velachery Main Road, Near Gurunanak College, </p>
                <p>Velachery, Chennai, Tamil Nadu 600 042.</p>
                <div class="pad-tp">
                    <p>Tel: +91 44 33161718</p>
                    <p>Fax: +91 44 33161717</p>
                </div>
            </div>
        </div>
        <div class="col-md-8">
            <div class="map">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3887.6970871836966!2d80.2164684!3d12.991216!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a526763b48e60eb%3A0xdb3a29009036c251!2sPhoenix+Marketcity!5e0!3m2!1sen!2sin!4v1436176099978" width="100%" height="250" frameborder="0" style="border:0" allowfullscreen></iframe>
            </div>
        </div>
    </div>
    <div class="contactform">
        <div class="col-md-12">
            <div class="conct-head text-center">
                <h1>How can we be of service?</h1>
            </div>
        </div>
        <form>
            <div class="row">
                <div class="col-md-3">
                    <div class="form-group">
                        <input type="text" class="form-control" id="exampleInputEmail1" placeholder="First Name">
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" id="exampleInputEmail1" placeholder="Last Name">
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Email Id">
                    </div>
                    <div class="form-group">
                        <input type="tel" class="form-control" id="exampleInputEmail1" placeholder="Contact">
                    </div>
                </div>
                <div class="col-md-6">
                    <textarea placeholder="Request"></textarea>
                </div>
            </div>
        </form>
        <div class="send  text-center">
            <a href="#">Submit</a>
        </div>
    </div>
</div>